var codeScatterploArrays = [
  {
    "departmentCode": "BID Lab",
    "divisionCode": "BID Lab",
    "Code": "Nexso",
    "Day of Published Date": "04/06/2017",
    "daysPublished": 733,
    "pageviews": 1248,
    "pageviewsperday": 1.7
  },
  {
    "departmentCode": "BID Lab",
    "divisionCode": "BID Lab",
    "Code": "SmartMap",
    "Day of Published Date": "04/06/2017",
    "daysPublished": 733,
    "pageviews": 1291,
    "pageviewsperday": 1.76
  },
  {
    "departmentCode": "IFD",
    "divisionCode": "FMM",
    "Code": "AP-LATAM",
    "Day of Published Date": "07/23/2018",
    "daysPublished": 260,
    "pageviews": 591,
    "pageviewsperday": 2.26
  },
  {
    "departmentCode": "IFD",
    "divisionCode": "FMM",
    "Code": "Plataforma de Gestión Catastral Multipaís",
    "Day of Published Date": "07/25/2018",
    "daysPublished": 258,
    "pageviews": 805,
    "pageviewsperday": 3.11
  },
  {
    "departmentCode": "IFD",
    "divisionCode": "ICS",
    "Code": "SIMPLE-LAT",
    "Day of Published Date": "04/01/2017",
    "daysPublished": 738,
    "pageviews": 1277,
    "pageviewsperday": 1.73
  },
  {
    "departmentCode": "INE",
    "divisionCode": "WSA",
    "Code": "Evaluación de Reciclaje Inclusivo",
    "Day of Published Date": "06/07/2017",
    "daysPublished": 671,
    "pageviews": 3654,
    "pageviewsperday": 5.44
  },
  {
    "departmentCode": "INE",
    "divisionCode": "WSA",
    "Code": "Hydro-BID",
    "Day of Published Date": "04/03/2017",
    "daysPublished": 736,
    "pageviews": 5195,
    "pageviewsperday": 7.05
  },
  {
    "departmentCode": "KIC",
    "divisionCode": "ISU",
    "Code": "R Library Numbers for Development",
    "Day of Published Date": "04/05/2017",
    "daysPublished": 734,
    "pageviews": 1001,
    "pageviewsperday": 1.36
  },
  {
    "departmentCode": "KIC",
    "divisionCode": "KIC",
    "Code": "IDBx Data Engine",
    "Day of Published Date": "04/06/2017",
    "daysPublished": 733,
    "pageviews": 951,
    "pageviewsperday": 1.3
  },
  {
    "departmentCode": "KIC",
    "divisionCode": "KLD",
    "Code": "AEDES Detector",
    "Day of Published Date": "08/04/2017",
    "daysPublished": 613,
    "pageviews": 871,
    "pageviewsperday": 1.42
  },
  {
    "departmentCode": "KIC",
    "divisionCode": "KLD",
    "Code": "Consul",
    "Day of Published Date": "12/05/2017",
    "daysPublished": 490,
    "pageviews": 2964,
    "pageviewsperday": 6.04
  },
  {
    "departmentCode": "KIC",
    "divisionCode": "KLD",
    "Code": "Gmapsdistance",
    "Day of Published Date": "01/17/2018",
    "daysPublished": 447,
    "pageviews": 906,
    "pageviewsperday": 2.02
  },
  {
    "departmentCode": "KIC",
    "divisionCode": "KLD",
    "Code": "Gobierto",
    "Day of Published Date": "05/17/2018",
    "daysPublished": 327,
    "pageviews": 1045,
    "pageviewsperday": 3.19
  },
  {
    "departmentCode": "KIC",
    "divisionCode": "KLD",
    "Code": "MapMap",
    "Day of Published Date": "12/05/2017",
    "daysPublished": 490,
    "pageviews": 4027,
    "pageviewsperday": 8.2
  },
  {
    "departmentCode": "KIC",
    "divisionCode": "KLD",
    "Code": "Pydatajson",
    "Day of Published Date": "08/04/2017",
    "daysPublished": 613,
    "pageviews": 431,
    "pageviewsperday": 0.7
  },
  {
    "departmentCode": "KIC",
    "divisionCode": "KLD",
    "Code": "Tabula",
    "Day of Published Date": "08/01/2017",
    "daysPublished": 616,
    "pageviews": 1056,
    "pageviewsperday": 1.71
  },
  {
    "departmentCode": "KIC",
    "divisionCode": "KLD",
    "Code": "Textar",
    "Day of Published Date": "08/04/2017",
    "daysPublished": 613,
    "pageviews": 721,
    "pageviewsperday": 1.17
  },
  {
    "departmentCode": "KIC",
    "divisionCode": "KLD",
    "Code": "Vota Inteligente",
    "Day of Published Date": "12/05/2017",
    "daysPublished": 490,
    "pageviews": 914,
    "pageviewsperday": 1.86
  },
  {
    "departmentCode": "SPD",
    "divisionCode": "SPD",
    "Code": "Indicator aggregator",
    "Day of Published Date": "11/13/2017",
    "daysPublished": 512,
    "pageviews": 4154,
    "pageviewsperday": 8.1
  }
]