var codeScatterploArrays = [
    {
        "departmentCode": "IFD",
        "pageviews": 3,
        "Code": "AP-LATAM",
        "daysPublished": 119,
        "publishedDate": "07-23-2018"
    },
    {
        "departmentCode": "IFD",
        "pageviews": 4.33898305084746,
        "Code": "Massive change detection",
        "daysPublished": 117,
        "publishedDate": "07-25-2018"
    },
    {
        "departmentCode": "IFD",
        "pageviews": 1.84782608695652,
        "Code": "SIMPLE-LAT",
        "daysPublished": 597,
        "publishedDate": "04-01-2017"
    },
    {
        "departmentCode": "INE",
        "pageviews": 6.17702448210923,
        "Code": "Evaluación de Reciclaje Inclusivo",
        "daysPublished": 530,
        "publishedDate": "06-07-2017"
    },
    {
        "departmentCode": "INE",
        "pageviews": 7.74496644295302,
        "Code": "Hydro-BID",
        "daysPublished": 595,
        "publishedDate": "04-03-2017"
    },
    {
        "departmentCode": "KIC",
        "pageviews": 1.56025369978858,
        "Code": "AEDES Detector",
        "daysPublished": 472,
        "publishedDate": "08-04-2017"
    },
    {
        "departmentCode": "KIC",
        "pageviews": 7.78857142857143,
        "Code": "Consul",
        "daysPublished": 349,
        "publishedDate": "12-05-2017"
    },
    {
        "departmentCode": "KIC",
        "pageviews": 1.82084690553746,
        "Code": "Gmapsdistance",
        "daysPublished": 306,
        "publishedDate": "01-17-2018"
    },
    {
        "departmentCode": "KIC",
        "pageviews": 4.3475935828877,
        "Code": "Gobierto",
        "daysPublished": 186,
        "publishedDate": "05-17-2018"
    },
    {
        "departmentCode": "KIC",
        "pageviews": 1.41315345699831,
        "Code": "IDBx Data Engine",
        "daysPublished": 592,
        "publishedDate": "04-06-2017"
    },
    {
        "departmentCode": "KIC",
        "pageviews": 10.38,
        "Code": "MapMap",
        "daysPublished": 349,
        "publishedDate": "12-05-2017"
    },
    {
        "departmentCode": "KIC",
        "pageviews": 0.727272727272727,
        "Code": "Pydatajson",
        "daysPublished": 472,
        "publishedDate": "08-04-2017"
    },
    {
        "departmentCode": "KIC",
        "pageviews": 1.47306397306397,
        "Code": "R Library Numbers for Development",
        "daysPublished": 593,
        "publishedDate": "04-05-2017"
    },
    {
        "departmentCode": "KIC",
        "pageviews": 1.80882352941176,
        "Code": "Tabula",
        "daysPublished": 475,
        "publishedDate": "08-01-2017"
    },
    {
        "departmentCode": "KIC",
        "pageviews": 1.25369978858351,
        "Code": "Textar",
        "daysPublished": 472,
        "publishedDate": "08-04-2017"
    },
    {
        "departmentCode": "KIC",
        "pageviews": 1.97428571428571,
        "Code": "Vota Inteligente",
        "daysPublished": 349,
        "publishedDate": "12-05-2017"
    },
    {
        "departmentCode": "MIF",
        "pageviews": 1.77234401349073,
        "Code": "Nexso",
        "daysPublished": 592,
        "publishedDate": "04-06-2017"
    },
    {
        "departmentCode": "MIF",
        "pageviews": 1.88870151770658,
        "Code": "SmartMap",
        "daysPublished": 592,
        "publishedDate": "04-06-2017"
    },
    {
        "departmentCode": "SCL",
        "pageviews": 2.45806451612903,
        "Code": "Clasificador de Datos Atípicos",
        "daysPublished": 154,
        "publishedDate": "06-18-2018"
    },
    {
        "departmentCode": "SPD",
        "pageviews": 10.4327956989247,
        "Code": "Indicator aggregator",
        "daysPublished": 371,
        "publishedDate": "11-13-2017"
    }
];